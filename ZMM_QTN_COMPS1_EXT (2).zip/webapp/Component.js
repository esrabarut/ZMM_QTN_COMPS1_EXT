jQuery.sap.declare("s2p.mm.pur.qtn.compares1.ZMM_QTN_COMPS1_EXT.Component");
// use the load function for getting the optimized preload file if present
sap.ui.component.load({
	name: "s2p.mm.pur.qtn.compares1",
	// Use the below URL to run the extended application when SAP-delivered application is deployed on SAPUI5 ABAP Repository
	url: "/sap/bc/ui5_ui5/sap/MM_QTN_COMPS1" // we use a URL relative to our own component
		// extension application is deployed with customer namespace
});
this.s2p.mm.pur.qtn.compares1.Component.extend("s2p.mm.pur.qtn.compares1.ZMM_QTN_COMPS1_EXT.Component", {
	metadata: {
		version: "1.0.0",
		config: {},
		customizing: {
			"sap.ui.controllerExtensions": {
				"s2p.mm.pur.qtn.compares1.controller.Compare": {
					"controllerName": "s2p.mm.pur.qtn.compares1.ZMM_QTN_COMPS1_EXT.controller.CompareCustom"
				}
			}
		}
	}
});