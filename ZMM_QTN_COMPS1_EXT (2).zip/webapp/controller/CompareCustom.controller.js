sap.ui.define([
	"s2p/mm/pur/qtn/compares1/controller/BaseController",
	"sap/ui/model/odata/v2/ODataModel",
	"s2p/mm/pur/qtn/compares1/model/formatter",
	"s2p/mm/pur/qtn/compares1/utils/helper/HelperModel",
	"s2p/mm/pur/qtn/compares1/utils/Constant",
	"sap/ui/model/json/JSONModel",
	"sap/ui/generic/app/transaction/DraftController",
	"sap/ui/core/format/NumberFormat"
], function (B, O, f, H, C, J, D, N) {
	"use strict";
	return sap.ui.controller("s2p.mm.pur.qtn.compares1.ZMM_QTN_COMPS1_EXT.controller.CompareCustom", {
		//    onInit: function () {
		//        this.oDataModel = this.getODataModel();
		//        this.oDataModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
		//        this.oDataModel.attachBatchRequestCompleted(jQuery.proxy(this._onBatchRequestCompleted, this));
		//        this.oSupplierQuotationModel = this.getModel(C.SUPPLIER_QUOTATION_MODEL);
		//        this.oView = this.getView();
		//        this.oView.setModel(this.oDataModel);
		//        this.oHelperModel = H;
		//        var j = new J({
		//            isInitial: true,
		//            isDraft: true
		//        });
		//        this.oView.setModel(j, C.BEHAVIOR_MODEL);
		//        this.oSupplierQuotationHead = this.oView.byId(C.SUPPLIER_QUOTATION_HEAD);
		//        this.oBlockLayoutItemContainer = this.oView.byId(C.BLOCK_LAYOUT_CONTAINER);
		//        this.oFullyAwardedItemsChart = this.oView.byId(C.FULLY_AWARDED_BAR_CHART);
		//        this.oComparePage = this.oView.byId(C.COMPARE_PAGE);
		//        this.oMessagePopoverButton = this.oView.byId(C.MESSAGE_POPOVER_BUTTON);
		//        this.oEditButton = this.oView.byId(C.EDIT_BUTTON);
		//        this.getRouter().attachRouteMatched(this.onRouteMatched, this);
		//        this._initErrorPopover();
		//        this.loadedQtn = 0;
		//        this.mDraftContextPath = "";
		//        this.oSupplierQuotationItemPath = [];
		//        this.awdEnableSupplierQuotation = [];
		//        this.oInvalidSupplierQuotations = {};
		//        this.oDataModel.setDeferredGroups(["Changes"]);
		//        this.oDraftController = new D(this.oDataModel);
		//        this.bErrorOccured = false;
		//        $(window).resize(jQuery.proxy(this._onResizeWindow, this));
		//    },
		//    formatter: f,
		//    onRouteMatched: function (e) {
		//        var n = e.getParameter("name");
		//        if (n === C.COMPARE_NAVIGATION) {
		//            var a = e.getParameter("arguments");
		//            var r = a.rfqID, q = a.qtnIDs;
		//            this.oMetaModel = this.oDataModel.getMetaModel();
		//            this.oView.setBusy(true);
		//            if (r === this.sLastLoadedRfq && q === this.sLastLoadedQtn) {
		//                this.oMetaModel.loaded().then(jQuery.proxy(this._onMetadataLoadedForDraftCheck, this));
		//            } else {
		//                this.oMetaModel.loaded().then(jQuery.proxy(this._onMetadataLoaded, this));
		//                if (r !== this.sLastLoadedRfq) {
		//                    this.sLastLoadedRfq = r;
		//                }
		//                if (q !== this.sLastLoadedQtn) {
		//                    this.sLastLoadedQtn = q;
		//                }
		//            }
		//        } else if (n === "default") {
		//            var p = e.getParameters();
		//            p.name = "internal";
		//            p.arguments.rfqID = this.sLastLoadedRfq;
		//            this.oDataModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
		//            this.updateBehaviorModel(C.IS_INITIAL, true);
		//            this.bErrorOccured = false;
		//        }
		//    },
		//    _onMetadataLoaded: function () {
		//        this._destroyContentOfOldData();
		//        this._loadDraftAdministrativeData(this._onLoadRequestForQuotationSuccessCallback);
		//    },
		//    _onMetadataLoadedForDraftCheck: function () {
		//        this._loadDraftAdministrativeData(this._onLoadRequestForQuotationDraftCheckSuccessCallback);
		//    },
		//    _loadDraftAdministrativeData: function (s) {
		//        this.oDataModel.read(C.GET_ODATA_RFQ(this.sLastLoadedRfq), {
		//            success: jQuery.proxy(s, this),
		//            urlParameters: { "$expand": "DraftAdministrativeData" },
		//            error: jQuery.proxy(this._onLoadRequestForQuotationErrorCallback, this)
		//        });
		//    },
		//    _loadSupplierQuotation: function (q) {
		//        if (q && q.length > 0) {
		//            var F = this._prepareSupplierQuotationFilter(q, C.DRAFT_UUID, true);
		//            this.oDataModel.read(C.ODATA_ROOT_SIGN + C.SUPPLIER_QUOTATION_ENTITY_SET, {
		//                filters: F,
		//                success: jQuery.proxy(this._onLoadSupplierQuotationSuccessCallback, this)
		//            });
		//        }
		//    },
		//    _loadSupplierQuotationItems: function (r, q) {
		//        jQuery.sap.log.info("Has to be done through a great developer like Max!");
		//        var F = this._prepareSupplierQuotationFilter(q, C.DRAFT_UUID, true);
		//        F.push.apply(F, [new sap.ui.model.Filter(C.REQUEST_FOR_QUOTATION, sap.ui.model.FilterOperator.EQ, r)]);
		//        this.oDataModel.read(C.ODATA_ROOT_SIGN + C.SUPPLIER_QUOTATION_ITEM_ENTITY_SET, {
		//            filters: F,
		//            success: jQuery.proxy(this._onLoadSupplierQuotationItemSuccessCallback, this)
		//        });
		//    },
		//    onChangeAwardedQuantity: function (e) {
		//        var c = e.getSource();
		//        var p = this.oDataModel.getProperty(c.getBindingContext().getPath());
		//        if (c) {
		//            var i = this._detectCurrentIndex(c);
		//            var r = Math.abs(p.RequestedQuantity);
		//            var s = c.getValue();
		//            if (!s) {
		//                s = "0";
		//            }
		//            var a = this.formatter.parseFloatNumber(s);
		//            var A = this._countSelectedQuantityOfPosition(i);
		//            var q = Math.abs(p.QuotationQuantity);
		//            var d = this.oView.byId(C.DRAFT_INDICTAOR);
		//            if (a <= q) {
		//                A += a;
		//                var h = this._removeEntryFromErrorPopover(p.SupplierQuotation, p.SupplierQuotationItem);
		//                if (h) {
		//                    this.oMessagePopoverButton.setVisible(false);
		//                }
		//                this._setInputState(c, false, sap.ui.core.ValueState.None);
		//            } else {
		//                this._setInputState(c, true, sap.ui.core.ValueState.Error);
		//                this._removeEntryFromErrorPopover(p.SupplierQuotation, p.SupplierQuotationItem);
		//                this._addEntryToErrorPopover(a, p);
		//                this.oMessagePopoverButton.setVisible(true);
		//                this.oView.setBusy(false);
		//                d.clearDraftState();
		//            }
		//            this.oDataModel.setProperty(c.getBindingContext().getPath() + "/AwardedQuantity", a.toString());
		//            d.showDraftSaving();
		//            this._calcAwardedNetAmount(i);
		//            this._calcTotalAwardedNetAmount();
		//            this._updateFullySelectedMicroBarChart(p.SupplierQuotationItem, r, A);
		//            this._updateSelectedRequestedRatioBarChart(i, r, A);
		//            if (!this.oComparePage.getShowFooter()) {
		//                this.oComparePage.setShowFooter(true);
		//            }
		//        }
		//    },
		//    onSelectAllItemsOfPosition: function (e) {
		//        var b = e.getSource();
		//        var i = this._detectCurrentIndex(b);
		//        if (typeof i === "string") {
		//            this._selectMaxQuantity(i);
		//        }
		//    },
		//    onPressAward: function (e) {
		//        var s = e.getSource();
		//        if (s) {
		//            var p = this.oDataModel.getProperty(s.getBindingContext().getPath());
		//            if (p) {
		//                var S = p.SupplierQuotation;
		//                var i = C.QTN_LIFECYCLE_STATUS_EXPR.test(p.QtnLifecycleStatus);
		//                if (S !== undefined && S !== "" && i) {
		//                    var u = {
		//                        SupplierQuotation: S,
		//                        DraftUUID: C.DRAFT_UUID,
		//                        IsActiveEntity: C.IS_ACTIVE_ENTITY
		//                    };
		//                    this.oView.setBusy(true);
		//                    var F = {};
		//                    F.fnCallback = this._onAwardSuccessCallback;
		//                    F.arguments = s;
		//                    this._oDataModelCallFunction(C.SUPPLIER_QUOTATION_AWARD_ACTION, F, this._onAwardErrorCallback, u);
		//                } else {
		//                    if (!i) {
		//                        var r = this.getModel(C.I18N_MODEL);
		//                        var t = r.getText(C.INVALID_STATUS_TITLE);
		//                        var T = r.getText(C.INVALID_STATUS_TEXT);
		//                        var b = r.getText(C.OK_BUTTON);
		//                        this.oHelperModel.getDialogHelper.createErrorDialog(t, T, b);
		//                    }
		//                }
		//            }
		//        }
		//    },
		//    onPressOpenMessagePopover: function (e) {
		//        this.oMessagePopover.openBy(e.getSource());
		//    },
		//    onPressEdit: function (e) {
		//        var c = e.getSource();
		//        if (c) {
		//            this.oDataModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
		//            this.oDataModel.read(C.GET_ODATA_RFQ(this.sLastLoadedRfq), {
		//                success: jQuery.proxy(this._onLoadRequestForQuotationDraftOnlySuccessCallback, this),
		//                urlParameters: { "$expand": "DraftAdministrativeData" },
		//                error: jQuery.proxy(this._onLoadRequestForQuotationErrorCallback, this)
		//            });
		//        }
		//    },
		//    onPressSave: function (e) {
		//        if (Object.keys(JSON.parse(this.oMessagePopoverModel.getJSON())).length === 0) {
		//            this.oView.setBusy(true);
		//            var c = this.oDataModel.getContext(this.sRfqDraftContextPath);
		//            var p = this.oDraftController.activateDraftEntity(c);
		//            p.then(jQuery.proxy(this._onDraftSavedSuccesCallback, this));
		//            p.catch(jQuery.proxy(this._onDraftSavedErrorCallback, this));
		//        } else {
		//            var r = this.getModel(C.I18N_MODEL).getResourceBundle();
		//            var t = r.getText(C.SAVE_ERROR_TITLE);
		//            var E = r.getText(C.SAVE_ERROR_TEXT);
		//            var b = r.getText(C.CLOSE_BUTTON_TEXT);
		//            var d = this.oHelperModel.getDialogHelper().createErrorDialog(t, E, b);
		//            d.open();
		//        }
		//    },
		//    onPressCancel: function (e) {
		//        this.oDataModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
		//        this.oComparePage.setShowFooter(false);
		//        this.oView.setBusy(true);
		//        this.oDataModel.remove(this.sRfqDraftContextPath, {
		//            success: jQuery.proxy(this._onRemoveDraftSuccessCallback, this),
		//            error: jQuery.proxy(this._onRemoveDraftErrorCallback, this)
		//        });
		//    },
		//    _setInputState: function (c, s, v) {
		//        c.setShowValueStateMessage(s);
		//        c.setValueState(v);
		//    },
		//    _initErrorPopover: function () {
		//        if (!this.oMessagePopover) {
		//            var m = new sap.m.MessageItem({
		//                title: "{title}",
		//                description: "{description}",
		//                subtitle: "{subtitle}"
		//            });
		//            var M = new sap.m.MessagePopover({
		//                items: {
		//                    path: "/",
		//                    template: m
		//                }
		//            });
		//            this.oMessagePopoverModel = new sap.ui.model.json.JSONModel();
		//            M.setModel(this.oMessagePopoverModel);
		//            this.oMessagePopover = M;
		//        }
		//    },
		//    _addEntryToErrorPopover: function (a, p) {
		//        var r = this.getModel(C.I18N_MODEL).getResourceBundle();
		//        var j = JSON.parse(this.oMessagePopoverModel.getJSON());
		//        var m = [];
		//        if (j instanceof Array) {
		//            m = j;
		//        }
		//        var d = r.getText(C.MESSAGE_ITEM_QUANTITY_DESCRIPTION, [
		//            a,
		//            p.Material,
		//            p.SupplierQuotationItem,
		//            p.SupplierQuotation
		//        ]);
		//        d += " " + r.getText(C.MESSAGE_ITEM_QUANTITY_DESCRIPTION_SECOND_PART, [p.QuotationQuantity]);
		//        var M = {
		//            title: r.getText(C.MESSAGE_ITEM_QUANTITY_TITLE),
		//            description: d,
		//            subtitle: r.getText(C.MESSAGE_ITEM_QUANTITY_SUBTITLE),
		//            supplierQuotation: p.SupplierQuotation,
		//            supplierQuotationItem: p.SupplierQuotationItem
		//        };
		//        m.push(M);
		//        this.oMessagePopoverModel.setData(m);
		//        this.oMessagePopoverButton.setText(m.length.toString());
		//        this.oMessagePopoverModel.updateBindings();
		//    },
		//    _removeEntryFromErrorPopover: function (s, S) {
		//        var j = JSON.parse(this.oMessagePopoverModel.getJSON());
		//        if (j instanceof Array) {
		//            for (var i = 0; i < j.length; i++) {
		//                var o = j[i];
		//                if (o.supplierQuotation === s && o.supplierQuotationItem === S) {
		//                    j.splice(i, 1);
		//                }
		//            }
		//            this.oMessagePopoverButton.setText(j.length.toString());
		//            this.oMessagePopoverModel.setData(j);
		//            this.oMessagePopoverModel.updateBindings();
		//        }
		//        return j.length === 0 ? true : false;
		//    },
		//    onSelectAllItemsOfQuotation: function (e) {
		//        var b = e.getSource();
		//        var r = C.SUPLR_QTN_HEAD_EXPR.exec(b.getId())[0];
		//        if (typeof r === "string") {
		//            var I = r.slice(-1);
		//            var s = true;
		//            var i = 0;
		//            while (s) {
		//                s = this._selectMaxQuantity(i + "-" + I);
		//                i++;
		//            }
		//        }
		//    },
		//    _selectMaxQuantity: function (i) {
		//        var a = this.oView.byId(C.GET_AWARDED_QUANTITY(i));
		//        if (a === undefined) {
		//            return false;
		//        }
		//        var p = this.oDataModel.getProperty(a.getBindingContext().sPath);
		//        if (p) {
		//            var q = this.formatter.formatFloatNumber(p.QuotationQuantity, 3);
		//            a.getInnerControls()[0].setValue(q);
		//            a.fireChange();
		//            return true;
		//        }
		//        return false;
		//    },
		//    _onValueHelpOk: function (e) {
		//        this.getParent().destroy();
		//    },
		//    _countSelectedQuantityOfPosition: function (I) {
		//        var b = true;
		//        var i = 0;
		//        var a = 0;
		//        while (b) {
		//            var n = I.substring(0, 2) + i.toString();
		//            if (I !== n) {
		//                var o = this.oView.byId(C.GET_AWARDED_QUANTITY(n));
		//                if (o && o.getBindingContext()) {
		//                    var r = this.oDataModel.getProperty(o.getBindingContext().sPath);
		//                    var A = this.formatter.parseFloatNumber(o.getValue());
		//                    if (r && A <= r.QuotationQuantity) {
		//                        a += A;
		//                    }
		//                } else {
		//                    b = false;
		//                }
		//            }
		//            i++;
		//        }
		//        return a;
		//    },
		    _renderQtnPosItem: function (i, e) {
		        var s = sap.ui.xmlfragment(i, "s2p.mm.pur.qtn.compares1.ZMM_QTN_COMPS1_EXT.fragments.SupplierQuotationItem", this);
		        var S = s.getContent().pop();
		        var t = s.getHeaderToolbar();
		        if (S !== undefined && t !== undefined) {
		            t.bindElement(e);
		            S.bindElement(e);
		            t.updateBindingContext();
		            S.updateBindingContext();
		            this.oView.addDependent(s);
		            return s;
		        }
		        return undefined;
		    },
		//    _onLoadRequestForQuotationSuccessCallback: function (d, r) {
		//        if (r && r.statusCode === "200" && d.RequestForQuotation !== undefined) {
		//            var c = this.oDataModel.getContext(C.GET_ODATA_RFQ(d.RequestForQuotation));
		//            this.oView.setBindingContext(c);
		//            var q = this.sLastLoadedQtn.split(C.QUOTATION_SEPARATOR);
		//            q = this._removeInvalidSupplierQuotationsFromArray(q);
		//            this.iNumberOfQuotations = q.length;
		//            if (this.iNumberOfQuotations <= C.MAX_ALLOWED_NUMBER_OF_ITEMS_FOR_COMPARE) {
		//                this._loadSupplierQuotation(q);
		//                this._loadSupplierQuotationItems(d.RequestForQuotation, q);
		//            } else {
		//                var R = this.oView.getModel(C.I18N_MODEL).getResourceBundle();
		//                var t = R.getText(C.INVALID_NUMBER_OF_ITEMS_TITLE);
		//                var T = R.getText(C.INVALID_NUMBER_OF_ITEMS_TEXT);
		//                var b = R.getText(C.OK_BUTTON);
		//                var e = this.oHelperModel.getDialogHelper().createErrorDialog(t, T, b);
		//                e.open();
		//                this.oView.setBusy(false);
		//                this.updateBehaviorModel(C.IS_INITIAL, true);
		//            }
		//            this.oDraftAdministrativeData = d.DraftAdministrativeData;
		//        }
		//    },
		//    _onLoadRequestForQuotationDraftCheckSuccessCallback: function (d, r) {
		//        if (r && r.statusCode === "200" && d.RequestForQuotation !== undefined) {
		//            if (this.oDraftController.getDraftContext().isDraftEnabled(C.REQUEST_FOR_QUOTATION_SET)) {
		//                if (!d.DraftAdministrativeData || d.DraftAdministrativeData.DraftIsCreatedByMe) {
		//                    if (!d.DraftAdministrativeData) {
		//                        this.oView.byId("EditButton").setVisible(true);
		//                        this.oComparePage.setShowFooter(false);
		//                        this.updateBehaviorModel(C.IS_DRAFT, false);
		//                    } else {
		//                        this.oComparePage.setShowFooter(true);
		//                    }
		//                    if (!this.bErrorOccured) {
		//                        this.updateBehaviorModel(C.IS_INITIAL, false);
		//                    }
		//                    this.oView.setBusy(false);
		//                } else if (d.DraftAdministrativeData.InProcessByUser) {
		//                    this._onRFQDraftIsLocked();
		//                } else {
		//                    this._onRFQDraftIsLockedByUser();
		//                }
		//            }
		//        }
		//    },
		//    _onLoadRequestForQuotationDraftOnlySuccessCallback: function (d, r) {
		//        if (r && r.statusCode === "200" && d.RequestForQuotation !== undefined) {
		//            this.oDraftAdministrativeData = d.DraftAdministrativeData;
		//            this._createDraftForRFQ(this.oDataModel.getContext(C.GET_RFQ_CONTEXT_PATH(d.RequestForQuotation, C.DRAFT_UUID, "true")));
		//            this.oView.byId("EditButton").setVisible(false);
		//        }
		//    },
		//    _onRFQDraftCreatedSuccess: function (r) {
		//        if (r.response.statusCode === C.STATUS_CODE_OK) {
		//            this.sRfqDraftContextPath = r.context.sPath;
		//            var F = [];
		//            var q = this.sLastLoadedQtn.split(";");
		//            for (var i = 0; i < q.length; i++) {
		//                F.push.apply(F, [new sap.ui.model.Filter(C.SUPL_QUOTE_PROP, sap.ui.model.FilterOperator.EQ, q[i])]);
		//            }
		//            F.push.apply(F, [new sap.ui.model.Filter(C.IS_ACTIVE_ENTITY_PROP, sap.ui.model.FilterOperator.EQ, false)]);
		//            F.push.apply(F, [new sap.ui.model.Filter("RootDraftUUID", sap.ui.model.FilterOperator.EQ, r.data.DraftUUID)]);
		//            this.oDataModel.read("/" + C.SUPPLIER_QUOTATION_ITEM_ENTITY_SET, {
		//                filters: F,
		//                success: jQuery.proxy(this._onLoadDraftSupplierQuotationItemSuccessCallback, this),
		//                error: jQuery.proxy(this._onLoadDraftSupplierQuotationItemErrorCallback, this)
		//            });
		//        }
		//    },
		//    _onRFQDraftIsLocked: function () {
		//        var r = this.oView.getModel(C.I18N_MODEL).getResourceBundle();
		//        var t = r.getText(C.DRAFT_IS_LOCKED_TITLE);
		//        var u = this.oDraftAdministrativeData.InProcessByUserDescription || this.oDraftAdministrativeData.InProcessByUser;
		//        var T = r.getText(C.DRAFT_IS_LOCKED_TEXT, [String(u)]);
		//        var b = r.getText(C.OK_BUTTON);
		//        var d = this.oHelperModel.getDialogHelper().createErrorDialog(t, T, b);
		//        this.oDataModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
		//        var R = this.getRouter();
		//        var o = this.oDataModel;
		//        var a = new sap.m.Button({
		//            text: b,
		//            press: function () {
		//                d.close();
		//                o.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
		//                R.navTo("default");
		//            }
		//        });
		//        d.setBeginButton(a);
		//        d.open();
		//        this.oView.setBusy(false);
		//    },
		//    _onRFQDraftIsLockedByUser: function () {
		//        var r = this.oView.getModel(C.I18N_MODEL).getResourceBundle();
		//        var t = r.getText(C.WARNING_TITLE);
		//        var u = this.oDraftAdministrativeData.InProcessByUserDescription || this.oDraftAdministrativeData.InProcessByUser;
		//        var T = r.getText(C.DRAFT_LOCKED_BY_USER, [String(u)]);
		//        var b = r.getText(C.EDIT_BUTTON_TEXT);
		//        var e = r.getText(C.CANCEL_BUTTON_TEXT);
		//        var d = this.oHelperModel.getDialogHelper().createWarningDialog(t, T, e);
		//        var o = new sap.m.Button({
		//            text: b,
		//            press: jQuery.proxy(this._onPressEditForDraftCancel, this, d)
		//        });
		//        var R = this.getRouter();
		//        var a = this.oDataModel;
		//        var E = new sap.m.Button({
		//            text: e,
		//            press: function () {
		//                d.close();
		//                a.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
		//                R.navTo("default");
		//            }
		//        });
		//        d.setBeginButton(o);
		//        d.setEndButton(E);
		//        d.open();
		//        this.oView.setBusy(false);
		//    },
		//    _onPressEditForDraftCancel: function (d) {
		//        d.close();
		//        var c = this.oDataModel.getContext(C.GET_RFQ_CONTEXT_PATH(this.sLastLoadedRfq, C.DRAFT_UUID, "true"));
		//        var p = this.oDraftController.createEditDraftEntity(c, true);
		//        p.then(jQuery.proxy(this._onRFQDraftCreatedSuccess, this));
		//        p.catch(jQuery.proxy(this._onRFQDraftCreatedErrorCallback, this));
		//    },
		//    _onDraftCanceledForEditSuccessCallback: function () {
		//        this.oDataModel.read(C.GET_ODATA_RFQ(this.sLastLoadedRfq), {
		//            success: jQuery.proxy(this._onLoadRequestForQuotationSuccessCallback, this),
		//            urlParameters: { "$expand": "DraftAdministrativeData" },
		//            error: jQuery.proxy(this._onLoadRequestForQuotationErrorCallback, this)
		//        });
		//    },
		//    _onRemoveDraftSuccessCallback: function (r) {
		//        for (var i = 0; i < this.oSupplierQuotationItemPath.length; i++) {
		//            this.oDataModel.read(this.oSupplierQuotationItemPath[i], { success: jQuery.proxy(this._updateSupplierQuotationItem, this) });
		//        }
		//        this.updateBehaviorModel(C.IS_DRAFT, false);
		//        this._disableAwardBtnForAllSupQtns();
		//    },
		//    _updateSupplierQuotationItem: function (r) {
		//        var s = this.oView.byId(C.FULLY_SELECTED_MICRO_BAR_CHART);
		//        if (s) {
		//            s.destroyBars();
		//        }
		//        var t = 0;
		//        for (var i = 0; i < this.iNumberOfQuotationItems; i++) {
		//            var a;
		//            var T = 0;
		//            var I = "";
		//            var A = 0;
		//            for (var n = 0; n < this.iNumberOfQuotations; n++) {
		//                I = i.toString() + "-" + n.toString();
		//                var o = this.oView.byId(C.GET_AWARDED_QUANTITY(I));
		//                if (o !== undefined) {
		//                    var b = o.getParent().getParent().getBindingContext();
		//                    a = this.oDataModel.getProperty(b.getPath());
		//                    this._setAndUpdateBindingsOfControl(o, b);
		//                    var c = Math.abs(a.AwardedQuantity);
		//                    if (c <= Math.abs(a.QuotationQuantity)) {
		//                        if (a.NetPriceQuantity !== 0) {
		//                            A += Math.abs(a.AwardedQuantity) * parseFloat(a.NetPriceAmount) / Math.abs(a.NetPriceQuantity);
		//                        } else {
		//                            A += Math.abs(a.AwardedQuantity) * parseFloat(a.NetPriceAmount);
		//                        }
		//                        T += c;
		//                    }
		//                }
		//            }
		//            var d = this.oView.byId(C.GET_AWARDED_NET_AMOUNT_FIELD(i + "-0"));
		//            if (d) {
		//                t += A;
		//                d.setNumber(this.formatter.formatFloatNumber(A));
		//            }
		//            var R = Math.abs(a.RequestedQuantity);
		//            this._updateSelectedRequestedRatioBarChart(I, R, T);
		//            this._addFullyAwardedItemsChartBar(a.SupplierQuotationItem, R, T);
		//        }
		//        var e = this.oView.byId(C.TOTAL_NET_AMOUNT_AWARD_FIELD);
		//        if (e) {
		//            e.setNumber(this.formatter.formatFloatNumber(t));
		//        }
		//        this.oView.setBusy(false);
		//        if (r.AwardedQuantity > "0") {
		//            var g = this.awdEnableSupplierQuotation.findIndex(function (j) {
		//                return j.supQtn === r.SupplierQuotation;
		//            });
		//            this.awdEnableSupplierQuotation[g].isAwardable = true;
		//            var h = this.oView.byId(C.AWD_BTN_CP_ID_STR1 + g.toString() + C.AWD_BTN_CP_ID_STR2);
		//            h.setEnabled(this.awdEnableSupplierQuotation[g].isAwardable);
		//        }
		//    },
		//    _onBatchRequestCompleted: function (r) {
		//        var R = r ? r.getParameter("requests") : undefined;
		//        var o = this.oView.getModel(C.I18N_MODEL).getResourceBundle();
		//        var t;
		//        var T;
		//        var b = o.getText(C.OK_BUTTON);
		//        var d = this.oHelperModel.getDialogHelper().createWarningDialog(t, T, b);
		//        if (R && R.length === 2) {
		//            var a = this.oView.byId(C.DRAFT_INDICTAOR);
		//            var c = R[0].response;
		//            var e = R[1].response;
		//            if (c && e) {
		//                if (R[0].method === "MERGE" && c.statusCode === "204" && (R[1].method === "GET" && e.statusCode === "200")) {
		//                    this.oView.setBusy(false);
		//                    if (a) {
		//                        a.showDraftSaved();
		//                    }
		//                }
		//                if (c.statusCode === C.CONFLICT_STATUS_CODE) {
		//                    var E = this._getErrorFromResponse(c);
		//                    t = o.getText(C.ERROR_TITLE);
		//                    if (E && E.hasOwnProperty("message") && E.message.hasOwnProperty("value")) {
		//                        T = E.message.value;
		//                    } else {
		//                        T = o.getText(C.NOT_FOUND_TEXT);
		//                    }
		//                    d = this.oHelperModel.getDialogHelper().createErrorDialog(t, T, b);
		//                    d.open();
		//                    this.oView.setBusy(false);
		//                }
		//            }
		//            if (!c || !e) {
		//                this.oView.setBusy(false);
		//            }
		//        } else if (R && R.length === 1 && R[0].method === "POST") {
		//            E = this._getErrorFromResponse(R[0].response);
		//            if (E && R[0].response.statusCode === C.CONFLICT_STATUS_CODE) {
		//                t = o.getText(C.ERROR_TITLE);
		//                if (E && E.hasOwnProperty("message") && E.message.hasOwnProperty("value")) {
		//                    T = E.message.value;
		//                } else {
		//                    T = o.getText(C.NOT_FOUND_TEXT);
		//                }
		//                d = this.oHelperModel.getDialogHelper().createErrorDialog(t, T, b);
		//                this.oView.setBusy(false);
		//            }
		//        }
		//    },
		//    _onDraftSavedSuccesCallback: function (r) {
		//        this.oDataModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
		//        for (var i = 0; i < this.oSupplierQuotationItemPath.length; i++) {
		//            this.oDataModel.read(this.oSupplierQuotationItemPath[i], { success: jQuery.proxy(this._updateSupplierQuotationItem, this) });
		//        }
		//        this.oComparePage.setShowFooter(false);
		//        this.oView.setBusy(false);
		//        this.updateBehaviorModel(C.IS_DRAFT, false);
		//        var d = this.oView.byId(C.DRAFT_INDICTAOR);
		//        if (d) {
		//            d.clearDraftState();
		//        }
		//        this._disableAwardBtnForAllSupQtns();
		//    },
		//    _onDraftSavedErrorCallback: function (r) {
		//        if (r && r.response) {
		//            var R = this.getModel(C.I18N_MODEL).getResourceBundle();
		//            var t = R.getText(C.SAVE_ERROR_TITLE);
		//            var e = r.response.statusText;
		//            var b = R.getText(C.CLOSE_BUTTON_TEXT);
		//            var d = this.oHelperModel.getDialogHelper().createErrorDialog(t, e, b);
		//            d.open();
		//        }
		//        this.oView.setBusy(false);
		//        this.oComparePage.setShowFooter(true);
		//    },
		//    _onLoadSupplierQuotationSuccessCallback: function (d, r) {
		//        var R = d.results;
		//        if (R && R.length > 0) {
		//            R.sort(function (e, g) {
		//                return e.SupplierQuotation - g.SupplierQuotation;
		//            });
		//            var h = false;
		//            var o = this.getModel(C.I18N_MODEL).getResourceBundle();
		//            for (var n = 0; n < R.length; n++) {
		//                this.oInvalidSupplierQuotations[R[n].SupplierQuotation] = false;
		//                if (!C.QTN_LIFECYCLE_STATUS_EXPR.test(R[n].QtnLifecycleStatus)) {
		//                    this.oInvalidSupplierQuotations[R[n].SupplierQuotation] = true;
		//                }
		//            }
		//            for (var i = 0; i < R.length; i++) {
		//                if (C.QTN_LIFECYCLE_STATUS_EXPR.test(R[i].QtnLifecycleStatus)) {
		//                    var b = new sap.ui.layout.BlockLayoutCell(this.oView.createId(C.QUOTATION_HEADER_CELL + i.toString()));
		//                    b.addStyleClass("sapUiNoContentPadding");
		//                    var c = this.oDataModel.getContext(C.GET_SUPLR_QTN_CONTEXT_PATH(R[i].SupplierQuotation, R[i].RequestForQuotation));
		//                    if (this.oDraftController.getDraftContext().isDraftEnabled(C.SUPPLIER_QUOTATION_ENTITY_SET) && this.sRfqDraftContextPath) {
		//                        var p = this.oDataModel.getProperty(c.getPath());
		//                        this.oDraftController.createNewDraftEntity(C.REQUEST_FOR_QUOTATION_SET, this.sRfqDraftContextPath + "/to_SupplierQuotationCompare", p).then(jQuery.proxy(this._QTNDraftCreated, this, p));
		//                    }
		//                    if (!h) {
		//                        var s = sap.ui.xmlfragment(this.oView.createId("SupplierQuotationSummary"), "s2p.mm.pur.qtn.compares1.view.fragments.SupplierQuotationSummary", this);
		//                        var a = new sap.ui.layout.BlockLayoutCell({ width: 1 });
		//                        a.addStyleClass("sapUiNoContentPadding");
		//                        this._setAndUpdateBindingsOfControl(s, c);
		//                        a.addContent(s);
		//                        this.oSupplierQuotationHead.addContent(a);
		//                        h = true;
		//                    }
		//                    var S = sap.ui.xmlfragment(this.oView.createId("SupplierQuotationHead" + i.toString()), "s2p.mm.pur.qtn.compares1.view.fragments.SupplierQuotationHead", this);
		//                    S.getItems()[0].setTitle(o.getText(C.SUPLR_QTN_HEAD, [
		//                        R[i].SupplierQuotation,
		//                        R[i].SupplierName
		//                    ]));
		//                    this._setAndUpdateBindingsOfControl(S, c);
		//                    b.addContent(S);
		//                    this._setWidthOfBlockLayoutCell(b);
		//                    this.oSupplierQuotationHead.addContent(b);
		//                } else {
		//                    this.bErrorOccured = true;
		//                    this._createErrorDialogForAwardedQuotation();
		//                }
		//            }
		//        }
		//    },
		//    _onLoadSupplierQuotationItemSuccessCallback: function (d, r) {
		//        var R = d.results;
		//        if (R && R.length > 0) {
		//            var a = this._sortSupplierQuotationItem(R);
		//            this._createSupplierQuotationItems(a);
		//            this._createDraftForRFQ(this.oDataModel.getContext(C.GET_RFQ_CONTEXT_PATH(a[0].RequestForQuotation, C.DRAFT_UUID, "true")));
		//        }
		//    },
		//    _onLoadDraftSupplierQuotationItemSuccessCallback: function (d, r) {
		//        var R = d.results;
		//        if (R && R.length > 0) {
		//            var a = this._sortSupplierQuotationItem(R);
		//            this.updateBehaviorModel(C.IS_DRAFT, true);
		//            var s = this.oView.byId(C.FULLY_SELECTED_MICRO_BAR_CHART);
		//            if (s) {
		//                s.destroyBars();
		//            }
		//            this._createSupplierQuotationItemDraft(a);
		//        }
		//        this.oView.setBusy(false);
		//        if (!this.bErrorOccured) {
		//            this.updateBehaviorModel(C.IS_INITIAL, false);
		//        }
		//        if (!this.oComparePage.getShowFooter()) {
		//            this.oComparePage.setShowFooter(true);
		//        }
		//    },
		//    _onAwardSuccessCallback: function (a, d, r) {
		//        if (r.statusCode === C.STATUS_CODE_OK) {
		//            this.oView.setBusy(false);
		//            a.setVisible(false);
		//            var s = d.SupplierQuotation;
		//            this.oInvalidSupplierQuotations[s] = true;
		//            var i = this.getModel(C.I18N_MODEL).getResourceBundle();
		//            sap.m.MessageToast.show(i.getText(C.AWARD_SUCCESSFULLY, [s]));
		//            var I = C.SUPLR_QTN_HEAD_EXPR.exec(a.getId())[0];
		//            if (typeof I === "string") {
		//                this._removeSupplierQuotation(d.SupplierQuotation, I[I.length - 1]);
		//            }
		//        }
		//    },
		//    _onRFQDraftCreatedErrorCallback: function (r) {
		//        var R = this.oView.getModel(C.I18N_MODEL).getResourceBundle();
		//        var d;
		//        var t;
		//        var T;
		//        var b = R.getText(C.OK_BUTTON);
		//        if (r) {
		//            var e = this._getErrorFromResponse(r.response);
		//            if (e) {
		//                t = R.getText(C.ERROR_TITLE);
		//                if (e.hasOwnProperty("message") && e.message.hasOwnProperty("value")) {
		//                    T = e.message.value;
		//                } else {
		//                    T = R.getText(C.NOT_FOUND_TEXT);
		//                }
		//                d = this.oHelperModel.getDialogHelper().createErrorDialog(t, T, b);
		//                if (r.response.statusCode === C.CONFLICT_STATUS_CODE) {
		//                    var o = this.getRouter();
		//                    var a = this.oDataModel;
		//                    var c = new sap.m.Button({
		//                        text: b,
		//                        press: function () {
		//                            d.close();
		//                            a.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
		//                            o.navTo("default");
		//                        }
		//                    });
		//                    d.setBeginButton(c);
		//                }
		//            }
		//        }
		//        if (!d) {
		//            t = R.getText(C.NOT_FOUND_TITLE);
		//            T = R.getText(C.NOT_FOUND_TEXT);
		//            d = this.oHelperModel.getDialogHelper().createErrorDialog(t, T, b);
		//        }
		//        d.open();
		//        this.oView.setBusy(false);
		//    },
		//    _onLoadRequestForQuotationErrorCallback: function (r) {
		//        var d;
		//        var R = this.getModel(C.I18N_MODEL).getResourceBundle();
		//        var b = R.getText(C.OK_BUTTON);
		//        var t;
		//        var T;
		//        if (r) {
		//            var e = this._getErrorFromResponse(r);
		//            if (e && e.code === C.NO_AUTHORITY_BOPF_CODE) {
		//                t = R.getText(C.NO_AUTHORITY_TITLE);
		//                T = R.getText(C.NO_AUTHORITY_TEXT);
		//                var o = this.getRouter();
		//                var a = this.oDataModel;
		//                var c = new sap.m.Button({
		//                    text: b,
		//                    press: function () {
		//                        d.close();
		//                        a.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
		//                        o.navTo("default");
		//                    }
		//                });
		//                d.setBeginButton(c);
		//            }
		//        }
		//        if (!d) {
		//            t = R.getText(C.NOT_FOUND_TITLE);
		//            T = R.getText(C.NOT_FOUND_TEXT);
		//            d = this.oHelperModel.getDialogHelper().createErrorDialog(t, T, b);
		//        }
		//        d.open();
		//        this.bErrorOccured = true;
		//        this.oView.setBusy(false);
		//    },
		//    _onLoadDraftSupplierQuotationItemErrorCallback: function (r) {
		//        this.bErrorOccured = true;
		//        this.oView.setBusy(false);
		//    },
		//    _onRemoveDraftErrorCallback: function (r) {
		//        if (r && r.hasOwnProperty("responseText")) {
		//            var e = JSON.parse(r.responseText);
		//            if (e && e.hasOwnProperty("error")) {
		//                var R = this.getModel(C.I18N_MODEL).getResourceBundle();
		//                var b = R.getText(C.OK_BUTTON);
		//                var t;
		//                var d = this.oHelperModel.getDialogHelper().createErrorDialog(t, e, b);
		//                d.open();
		//            }
		//        }
		//        this.bErrorOccured = true;
		//        this.oView.setBusy(false);
		//    },
		//    _onAwardErrorCallback: function (r) {
		//        if (r) {
		//            var e = this._getErrorFromResponse(r);
		//            if (e) {
		//                var R = this.getModel(C.I18N_MODEL).getResourceBundle();
		//                var E = e.code;
		//                var s;
		//                if (e && e.hasOwnProperty("message") && e.message.hasOwnProperty("value")) {
		//                    s = e.message.value;
		//                } else {
		//                    s = R.getText(C.NOT_FOUND_TEXT);
		//                }
		//                this.oView.setBusy(false);
		//                var d;
		//                if (E === C.LOCKED_ERROR) {
		//                    var t = R.getText(C.QUOTATION_LOCKED_TITLE);
		//                    var b = R.getText(C.OK_BUTTON);
		//                    d = this.oHelperModel.getDialogHelper().createErrorDialog(t, s, b);
		//                    d.open();
		//                }
		//            }
		//        }
		//    },
		//    _createDraftForRFQ: function (c) {
		//        if (this.oDraftController.getDraftContext().isDraftEnabled(C.REQUEST_FOR_QUOTATION_SET)) {
		//            if (!this.oDraftAdministrativeData || this.oDraftAdministrativeData.DraftIsCreatedByMe) {
		//                var p = this.oDraftController.createEditDraftEntity(c, true);
		//                p.then(jQuery.proxy(this._onRFQDraftCreatedSuccess, this));
		//                p.catch(jQuery.proxy(this._onRFQDraftCreatedErrorCallback, this));
		//            } else if (this.oDraftAdministrativeData.InProcessByUser) {
		//                this._onRFQDraftIsLocked();
		//            } else {
		//                this._onRFQDraftIsLockedByUser();
		//            }
		//        }
		//    },
		    _prepareSupplierQuotationItemHead: function (b, c, s) {
		        var o = new sap.ui.layout.BlockLayoutCell(this.oView.createId("SupplierQuotationItemHead" + s));
		        o.addStyleClass("sapUiNoContentPadding");
		        var S = sap.ui.xmlfragment(this.oView.createId("SupplierQuotationItemHead" + s), "s2p.mm.pur.qtn.compares1.ZMM_QTN_COMPS1_EXT.fragments.SupplierQuotationItemHead", this);
		        this._setAndUpdateBindingsOfControl(S, c);
		        o.addContent(S);
		        o.setWidth(1);
		        b.addContent(o);
		        return S;
		    },
		//    _addFullyAwardedItemsChartBar: function (s, r, a) {
		//        var S = this.oView.byId(C.FULLY_SELECTED_MICRO_BAR_CHART);
		//        var o = new sap.suite.ui.microchart.StackedBarMicroChartBar(this.oView.createId("FullyAwardedBar" + s), {
		//            displayValue: s,
		//            value: 1
		//        });
		//        o.setValueColor(this._detectBarColor(r, a));
		//        if (S) {
		//            S.addBar(o);
		//        }
		//    },
		//    _updateFullySelectedMicroBarChart: function (s, r, a) {
		//        var F = this.oView.byId(C.FULLY_SELECTED_MICRO_BAR_CHART);
		//        if (F) {
		//            var b = F.getBars();
		//            for (var i = 0; i < b.length; i++) {
		//                if (b[i].getDisplayValue() === s) {
		//                    b[i].setValueColor(this._detectBarColor(r, a));
		//                }
		//            }
		//        }
		//    },
		//    _updateSelectedRequestedRatioBarChart: function (i, r, a) {
		//        var I = this.oView.byId(C.GET_ITEM_HEAD_BAR_CHART(i.substring(0, 2) + "0"));
		//        if (I) {
		//            I.setPercentValue(this._calculateRatio(r, a));
		//            I.setDisplayValue(a.toString() + " / " + r.toString());
		//            I.setState(this._detectBarState(r, a));
		//        }
		//    },
		//    _detectBarColor: function (r, a) {
		//        if (r && a && a >= r) {
		//            return sap.m.ValueColor.Good;
		//        }
		//        return sap.m.ValueColor.Critical;
		//    },
		//    _detectBarState: function (r, a) {
		//        if (r && a && a >= r) {
		//            return sap.ui.core.ValueState.Success;
		//        }
		//        return sap.ui.core.ValueState.Warning;
		//    },
		//    _detectCurrentIndex: function (c) {
		//        if (c) {
		//            var i = c.getId();
		//            var r = C.INDEX_EXPR.exec(i);
		//            if (r && r.length > 0 && typeof r[0] === "string") {
		//                return r[0];
		//            }
		//        }
		//        return undefined;
		//    },
		//    _detectCheapestPriceForItem: function (r) {
		//        var c = {};
		//        if (r && r instanceof Array) {
		//            for (var i = 0; i < r.length; i++) {
		//                var s = r[i].SupplierQuotationItem;
		//                var n = r[i].NetPriceAmount;
		//                if (c.hasOwnProperty(s)) {
		//                    if (parseFloat(c[s]) > parseFloat(n)) {
		//                        c[s] = n;
		//                    }
		//                } else {
		//                    c[s] = n;
		//                }
		//            }
		//        }
		//        return c;
		//    },
		//    _detectNetPriceAmountColor: function (s, i) {
		//        var o = s.getItems()[0];
		//        if (o) {
		//            if (i) {
		//                o.setNumberState(sap.ui.core.ValueState.Success);
		//            } else {
		//                o.setNumberState(sap.ui.core.ValueState.None);
		//            }
		//        }
		//    },
		//    _calculateRatio: function (r, a) {
		//        var R = 0;
		//        if (r && r !== 0) {
		//            R = r !== 0 ? a / r * 100 : 0;
		//        }
		//        return R > 100 ? 100 : Math.round(R * 100) / 100;
		//    },
		//    _sortSupplierQuotationItem: function (s) {
		//        s.sort(function (a, b) {
		//            var A = a.SupplierQuotation, c = b.SupplierQuotation;
		//            var d = A - c;
		//            if (d !== 0) {
		//                return d;
		//            }
		//            return a.SupplierQuotationItem - b.SupplierQuotationItem;
		//        });
		//        return s;
		//    },
		//    _calcTotalAwardedNetAmount: function () {
		//        var t = 0;
		//        for (var i = 0; i < this.iNumberOfQuotationItems; i++) {
		//            var I = i.toString() + "-0";
		//            var a = this.oView.byId(C.GET_AWARDED_NET_AMOUNT_FIELD(I));
		//            if (a !== undefined) {
		//                t += parseFloat(this.formatter.parseFloatNumber(a.getNumber()));
		//            }
		//        }
		//        var A = this.oView.byId(C.TOTAL_NET_AMOUNT_AWARD_FIELD);
		//        if (A) {
		//            A.setNumber(this.formatter.formatFloatNumber(t));
		//        }
		//    },
		//    _calcAwardedNetAmount: function (I) {
		//        var r = C.ROW_INDEX_EXPR.exec(I);
		//        if (r && r.length > 0) {
		//            var R = r[0];
		//            var a = 0;
		//            for (var i = 0; i < this.iNumberOfQuotations; i++) {
		//                var s = R + "-" + i.toString();
		//                var A = this.oView.byId(C.GET_AWARDED_QUANTITY(s));
		//                if (A !== undefined && A.getBindingContext()) {
		//                    var p = this.oDataModel.getProperty(A.getBindingContext().getPath());
		//                    var b = this.formatter.parseFloatNumber(A.getValue());
		//                    if (b <= Math.abs(p.QuotationQuantity)) {
		//                        if (p.NetPriceQuantity !== 0) {
		//                            a += b * parseFloat(p.NetPriceAmount) / Math.abs(p.NetPriceQuantity);
		//                        } else {
		//                            a += b * parseFloat(p.NetPriceAmount);
		//                        }
		//                    }
		//                }
		//            }
		//            this.oView.byId(C.GET_AWARDED_NET_AMOUNT_FIELD(R + "-0")).setNumber(this.formatter.formatFloatNumber(a));
		//        }
		//    },
		//    _createSupplierQuotationTilteRow: function (w) {
		//        if (w === 3 || w === 2) {
		//            var b = new sap.ui.layout.BlockLayoutCell({ width: w }).addStyleClass("sapUiNoContentPadding");
		//            var o = new sap.m.ObjectHeader({
		//                title: "{i18n>quotations}",
		//                backgroundDesign: "Translucent",
		//                responsive: true
		//            });
		//            b.addContent(o);
		//            return b;
		//        }
		//        return undefined;
		//    },
		//    _destroyContentOfOldData: function () {
		//        if (this.oSupplierQuotationHead) {
		//            this.oSupplierQuotationHead.destroyContent();
		//        }
		//        if (this.oBlockLayoutItemContainer) {
		//            var I = this.oBlockLayoutItemContainer.getContent();
		//            for (var i = 3; i < I.length; i++) {
		//                I[i].destroy();
		//            }
		//        }
		//        if (this.oFullyAwardedItemsChart) {
		//            this.oFullyAwardedItemsChart.destroyContent();
		//        }
		//        var h = this.oView.byId(C.HEADER_TITLE_ROW);
		//        if (h) {
		//            var a = h.getContent();
		//            if (a.length >= 2) {
		//                a[1].destroy();
		//            }
		//        }
		//    },
		    _createSupplierQuotationItems: function (r) {
		        this.oSupplierQuotationItemPath = [];
		        var a = 0;
		        if (this.iNumberOfQuotations !== 0) {
		            a = r.length / this.iNumberOfQuotations;
		            this.iNumberOfQuotationItems = a;
		        }
		        var c = this._detectCheapestPriceForItem(r);
		        for (var i = 0; i < a; i++) {
		            var b = new sap.ui.layout.BlockLayoutRow(this.oView.createId("ItemRow" + i.toString()), { oScope: this.oView });
		            var I = 0;
		            var s = "";
		            var S;
		            var d = false;
		            var e = this.iNumberOfQuotations;
		            for (var n = 0; n < this.iNumberOfQuotations; n++) {
		                s = i.toString() + "-" + n.toString();
		                I = i + n * a;
		                var o = r[I];
		                if (!this.oInvalidSupplierQuotations[o.SupplierQuotation]) {
		                    var g = this.oDataModel.getContext(C.GET_SUPLR_QTN_ITEM_CONTEXT_PATH(o.SupplierQuotation, o.SupplierQuotationItem, o.RequestForQuotation, C.DRAFT_UUID, "true"));
		                    this.oSupplierQuotationItemPath.push(g.getPath());
		                    if (!d) {
		                        S = this._prepareSupplierQuotationItemHead(b, g, s);
		                        var R = this.getModel(C.I18N_MODEL).getResourceBundle();
		                        S.getItems()[0].setTitle(R.getText(C.SUPLR_QTN_ITEM_HEAD_TITLE, [o.SupplierQuotationItem]));
		                        d = true;
		                    }
		                    var h = new sap.ui.layout.BlockLayoutCell(this.oView.createId(C.QUOTATION_ITEM_CELL + s));
		                    h.addStyleClass("sapUiNoContentPadding");
		                    var j = sap.ui.xmlfragment(this.oView.createId("SupplierQuotationItem" + s), "s2p.mm.pur.qtn.compares1.ZMM_QTN_COMPS1_EXT.fragments.SupplierQuotationItem", this);
		                    this._detectNetPriceAmountColor(j, c[r[I].SupplierQuotationItem] === r[I].NetPriceAmount);
		                    this._setAndUpdateBindingsOfControl(j, g);
		                    h.addContent(j);
		                    this._setWidthOfBlockLayoutCell(h);
		                    b.addContent(h);
		                } else {
		                    e--;
		                }
		            }
		            this.oBlockLayoutItemContainer.addContent(b);
		        }
		        var k = this._createSupplierQuotationTilteRow(e === 2 ? 2 : 3);
		        var l = this.oView.byId(C.HEADER_TITLE_ROW);
		        l.addContent(k);
		    },
		//    _createSupplierQuotationItemDraft: function (r) {
		//        var a = r.length / this.iNumberOfQuotations;
		//        var t = 0;
		//        for (var i = 0; i < a; i++) {
		//            var T = 0;
		//            var R = Math.abs(r[i].RequestedQuantity);
		//            var I = 0;
		//            var c = "";
		//            var A = 0;
		//            for (var n = 0; n < this.iNumberOfQuotations; n++) {
		//                c = i.toString() + "-" + n.toString();
		//                I = i + n * a;
		//                var s = r[I];
		//                var o = this.oDataModel.getProperty(C.GET_SUPLR_QTN_ITEM_CONTEXT_PATH(s.SupplierQuotation, s.SupplierQuotationItem, s.RequestForQuotation, C.DRAFT_UUID, "true"));
		//                if (s.AwardedQuantity !== o.AwardedQuantity && !this.oComparePage.getShowFooter()) {
		//                    this.oComparePage.setShowFooter(true);
		//                }
		//                var b = this.oDataModel.getContext(C.GET_SUPLR_QTN_ITEM_CONTEXT_PATH(s.SupplierQuotation, s.SupplierQuotationItem, s.RequestForQuotation, s.DraftUUID, "false"));
		//                var d = this.oView.byId(C.GET_AWARDED_QUANTITY(c));
		//                if (!this.oInvalidSupplierQuotations[s.SupplierQuotation]) {
		//                    this._setAndUpdateBindingsOfControl(d, b);
		//                } else {
		//                    d.setEnabled(false);
		//                    d.setEditable(false);
		//                }
		//                var e = Math.abs(s.AwardedQuantity);
		//                if (e <= Math.abs(s.QuotationQuantity)) {
		//                    T += e;
		//                    if (s.NetPriceQuantity !== 0) {
		//                        A += e * parseFloat(s.NetPriceAmount) / Math.abs(s.NetPriceQuantity);
		//                    } else {
		//                        A += e * parseFloat(s.NetPriceAmount);
		//                    }
		//                }
		//            }
		//            var g = this.oView.byId(C.GET_AWARDED_NET_AMOUNT_FIELD(i + "-0"));
		//            if (g) {
		//                t += A;
		//                g.setNumber(this.formatter.formatFloatNumber(A));
		//            }
		//            this._updateSelectedRequestedRatioBarChart(c, R, T);
		//            this._addFullyAwardedItemsChartBar(r[I].SupplierQuotationItem, R, T);
		//        }
		//        var h = this.oView.byId(C.TOTAL_NET_AMOUNT_AWARD_FIELD);
		//        if (h) {
		//            h.setNumber(this.formatter.formatFloatNumber(t));
		//        }
		//    },
		//    _removeSupplierQuotation: function (s, I) {
		//        for (var i = 0; i < this.iNumberOfQuotationItems; i++) {
		//            var c = i.toString() + "-" + I;
		//            var a = this.oView.byId(C.GET_AWARDED_QUANTITY(c));
		//            var p = this.oDataModel.getProperty(a.getBindingContext().getPath());
		//            if (p && p.SupplierQuotation) {
		//                if (s === p.SupplierQuotation) {
		//                    a.setEnabled(false);
		//                    a.setEditable(false);
		//                    var o = this.oDataModel.getContext(C.GET_SUPLR_QTN_ITEM_CONTEXT_PATH(p.SupplierQuotation, p.SupplierQuotationItem, p.RequestForQuotation, p.DRAFT_UUID, "true"));
		//                    this._setAndUpdateBindingsOfControl(a, o);
		//                }
		//            }
		//        }
		//    },
		//    _setAndUpdateBindingsOfControl: function (c, o) {
		//        if (c && o) {
		//            c.setBindingContext(o);
		//            c.bindElement(o.getPath());
		//            c.updateBindings();
		//        } else {
		//            jQuery.sap.log.error("Control or oContext in the function _setAndUpdateBindingsOfControl isn't defined!");
		//        }
		//    },
		//    _prepareSupplierQuotationFilter: function (q, d, I) {
		//        var F = [];
		//        for (var i = 0; i < q.length; i++) {
		//            F.push.apply(F, [new sap.ui.model.Filter(C.SUPL_QUOTE_PROP, sap.ui.model.FilterOperator.EQ, q[i])]);
		//        }
		//        if (typeof d === "string") {
		//            F.push.apply(F, [new sap.ui.model.Filter(C.DRAFT_UUID_PROP, sap.ui.model.FilterOperator.EQ, d)]);
		//        } else {
		//            jQuery.sap.log.error("DraftUUID in the function _prepareSupplierQuotationFilter isn't a string");
		//        }
		//        if (typeof I === "boolean") {
		//            F.push.apply(F, [new sap.ui.model.Filter(C.IS_ACTIVE_ENTITY_PROP, sap.ui.model.FilterOperator.EQ, I)]);
		//        } else {
		//            jQuery.sap.log.error("IsActiveEntity in the function _prepareSupplierQuotationFilter isn't a boolean");
		//        }
		//        return F;
		//    },
		//    _setWidthOfBlockLayoutCell: function (c) {
		//        var q = this.sLastLoadedQtn.split(C.QUOTATION_SEPARATOR);
		//        q = this._removeInvalidSupplierQuotationsFromArray(q);
		//        if (c) {
		//            var w = 1;
		//            if (q.length === 1) {
		//                w = 3;
		//            }
		//            c.setWidth(w);
		//        } else {
		//            jQuery.sap.log.error("Control in the function _setWidthOfBlockLayoutCell isn't defined!");
		//        }
		//    },
		//    _removeInvalidSupplierQuotationsFromArray: function (q) {
		//        if (q && q instanceof Array) {
		//            for (var i = 0; i < q.length; i++) {
		//                if (this.oInvalidSupplierQuotations[q[i]]) {
		//                    q.splice(i, 1);
		//                    i--;
		//                }
		//            }
		//            return q;
		//        }
		//        return undefined;
		//    },
		//    _createErrorDialogForAwardedQuotation: function () {
		//        var r = this.oView.getModel(C.I18N_MODEL).getResourceBundle();
		//        var t = r.getText(C.INVALID_QUOTATION_SELECTED_TITLE);
		//        var T = r.getText(C.INVALID_QUOTATION_SELECTED_TEXT);
		//        var b = r.getText(C.OK_BUTTON);
		//        var d = this.oHelperModel.getDialogHelper().createErrorDialog(t, T, b);
		//        this.oDataModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
		//        var R = this.getRouter();
		//        var o = this.oDataModel;
		//        var a = new sap.m.Button({
		//            text: b,
		//            press: function () {
		//                d.close();
		//                o.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
		//                R.navTo("default");
		//            }
		//        });
		//        d.setBeginButton(a);
		//        d.open();
		//    },
		//    _getErrorFromResponse: function (r) {
		//        var R = r;
		//        if (R && r.hasOwnProperty("response")) {
		//            R = R.response;
		//        }
		//        if (R && R.hasOwnProperty("responseText")) {
		//            var e = JSON.parse(R.responseText);
		//            if (e && e.hasOwnProperty("error")) {
		//                return e.error;
		//            }
		//        }
		//        return undefined;
		//    },
		//    _disableAwardBtnForAllSupQtns: function () {
		//        this.awdEnableSupplierQuotation = [];
		//        var a = this.sLastLoadedQtn.split(C.QUOTATION_SEPARATOR);
		//        a.sort(function (b, c) {
		//            return b - c;
		//        });
		//        for (var l = 0; l < a.length; l++) {
		//            var s = {
		//                supQtn: a[l],
		//                isAwardable: false
		//            };
		//            this.awdEnableSupplierQuotation.push(s);
		//            var A = this.oView.byId(C.AWD_BTN_CP_ID_STR1 + l.toString() + C.AWD_BTN_CP_ID_STR2);
		//            A.setEnabled(false);
		//        }
		//    },
		//    _onResizeWindow: function (e) {
		//    }
	});
});